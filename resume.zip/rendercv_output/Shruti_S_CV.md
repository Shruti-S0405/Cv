# Shruti S's CV

- Phone: +91 63825 80602
- Email: [shruti.sundar0405@gmail.com](mailto:shruti.sundar0405@gmail.com)
- Location: Chennai, TamilNadu, India
- LinkedIn: [Shruti-S0405](https://linkedin.com/in/Shruti-S0405)
- GitHub: [Shruti-S0405](https://github.com/Shruti-S0405)


# Summary

Eager and driven Computer Science and Engineering student seeking opportunities to apply academic knowledge, enhance skills, and contribute to innovative projects. Passionate about leveraging technology to solve real-world problems and keen to learn and grow in a dynamic environment.

# Education

## Panimalar Engineering College, Bachelor of Engineering in Computer Science and Engineering

- June 2022 to June 2026 
- Chennai, TamilNadu, India 
- Scored CGPA of 9/10

# Experience

## Cognizant, Intern

- July 2024 to Aug. 2024 

- Built an AI/ML application with a focus on GenAI in the Medicare Domain
- Skill set :- AngularJS, Python(Flask), Semantic Kernel, Okta, Azure LLM, MS SQL Server

# Projects

## [Quiz App](https://github.com/Shruti-S0405/Quiz-App-Springboot)

- Mar. 2025 - Developed a technical quiz application using Spring Boot and a microservices architecture
- Implemented dynamic quiz generation, service discovery using Netflix Eureka, and inter-service communication with OpenFeign to ensure scalability and modularity.
- Tech Stack: SpringBoot, Spring Cloud(Netflix Eureka, OpenFeign), PostgreSQL, React.js

## [CodeSense](https://github.com/Shruti-S0405/CodeSense)

- May 2024 - Leverages Gemini 1.5 Pro API to summarization
- Supports JS, Python, C, C++, Java, etc ...
- Tech Stack: ReactJS, Vite, NodeJS, Gemini

# Hackathons

## [SoundSynth](https://github.com/Shruti-S0405)

- Mar. 2024 - Converts audio files directly to summarized text for better and short reading.
- Won the best project award in PECTEAM - 2024 hosted in Panimalar Engineering College

## [Smart Insurance](https://github.com/Shruti-S0405/Smart-Insurance/)

- Aug. 2024 - Fraud and malpractice detection by insurance companies in claims submission
- Won 1st Runner Up in PECTechathon 2.0, 36 hours hacakthon hosted by Cognizant

# Certifications

## [Github Foundation](https://www.credly.com/badges/f3c9792a-9ba8-4535-b9a2-f05bd0abca66) by [Github](https://www.github.com/)

- Aug. 2024 
## [Oracle Cloud Infrastructure 2024 Generative AI Certified Professional](https://safe.b68dev.xyz/H1qf64oC.pdf) by [Oracle Cloud](https://cloud.oracle.com/)

- July 2024 
# Skills

- Web Development: HTML, CSS, JavaScript, React, Angular, Node.js, Express.js, 
- Programming: Java, JavaScript, C, Python
- Databases: MySQL, Microsoft SQL Server, PostgreSQL
- Tools: Postman, VS Code, Git, GitHub
- DevOps: Netlify, Vercel, Cloudflare
